package com.salespoint.SalesPointERP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesPointErpApplicationTests {

	@Test
	void contextLoads() {
	}

}
