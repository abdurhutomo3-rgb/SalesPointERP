package com.salespoint.SalesPointERP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesPointErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesPointErpApplication.class, args);
	}

}
